import React, { useState, useRef, useCallback, useEffect } from 'react';
import Webcam from 'react-webcam';
import { Camera, CameraOff, RefreshCw, Clock, Play, X, Volume2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { predictSign } from '../services/api'; // Assuming you have an API service for predicting signs

interface WebcamCaptureProps {
  onCapture?: (imageSrc: string) => void;
}

const WebcamCapture: React.FC<WebcamCaptureProps> = ({ onCapture }) => {
  const [isEnabled, setIsEnabled] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [detectedSign, setDetectedSign] = useState<string | null>(null);
  const [previousResult, setPreviousResult] = useState<string | null>('No hand detected');
  const [detectedSignsHistory, setDetectedSignsHistory] = useState<string[]>([]);
  const [processedSigns, setProcessedSigns] = useState<string[]>([]);
  const webcamRef = useRef<Webcam>(null);
  const [isLive, setIsLive] = useState(false);
  const [isLiveLetter, setIsLiveLetter] = useState(false);
  const [intervalId, setIntervalId] = useState<ReturnType<typeof setInterval> | null>(null);
  
  // Timer states
  const [showTimer, setShowTimer] = useState(false);
  const [timer, setTimer] = useState(3);
  const [timerActive, setTimerActive] = useState(false);
  const [liveTimer, setLiveTimer] = useState(5);

  const toggleWebcam = () => {
    setIsEnabled(!isEnabled);
    setCapturedImage(null);
    setResult(null);
    setIsLive(false);
    setIsLiveLetter(false);
    stopTimer();
    
    // Clear any existing interval
    if (intervalId) {
      clearInterval(intervalId);
      setIntervalId(null);
    }
  };

  const startTimer = () => {
    setShowTimer(true);
    setTimer(3);
    setTimerActive(true);
  };

  const stopTimer = () => {
    setShowTimer(false);
    setTimerActive(false);
    setTimer(3);
  };

  // Effect for timer countdown
  useEffect(() => {
    let timerId: ReturnType<typeof setInterval> | null = null;
    
    if (timerActive && timer > 0) {
      timerId = setInterval(() => {
        setTimer(prev => prev - 1);
      }, 1000);
    } else if (timerActive && timer === 0) {
      // When timer hits zero, capture the image
      capture();
      setTimerActive(false);
      setShowTimer(false);
    }
    
    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [timerActive, timer]);

  const capture = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) {
        setCapturedImage(imageSrc);
        if (onCapture) {
          onCapture(imageSrc);
        }
        
        // Make a prediction with the API
        setLoading(true);
        predictSign(imageSrc)
          .then(prediction => {
            setResult(prediction);
            if (prediction && prediction !== 'No hand detected') {
              if (previousResult === 'No hand detected') {
                setDetectedSign(prediction);
                setDetectedSignsHistory(prevSigns => [...prevSigns, prediction]);
                setPreviousResult(prediction);
                setTimeout(() => {
                  setPreviousResult('No hand detected');
                }, 5000); // Wait for 5 seconds before allowing the next prediction
              }
            }
          })
          .catch(error => {
            console.error('Error predicting sign:', error);
            setResult('Error detecting sign');
          })
          .finally(() => {
            setLoading(false);
          });
      }
    }
  }, [webcamRef, onCapture, previousResult]);

  const reset = () => {
    setCapturedImage(null);
    setResult(null);
    setDetectedSign(null);
    setDetectedSignsHistory([]);
    setProcessedSigns([]);
    setPreviousResult('No hand detected');
  };
  
  const toggleLiveDetection = () => {
    setIsLive(!isLive);
    setIsLiveLetter(false);
    
    // If turning on live detection
    if (!isLive) {
      setLiveTimer(5);
      const id = setInterval(() => {
        setLiveTimer(prev => {
          if (prev === 1) {
            if (webcamRef.current) {
              const imageSrc = webcamRef.current.getScreenshot();
              if (imageSrc) {
                // Don't set captured image in live mode to keep the webcam feed visible
                predictSign(imageSrc)
                  .then(prediction => {
                    setResult(prediction);
                    if (prediction && prediction !== 'No hand detected') {
                      if (previousResult === 'No hand detected') {
                        setDetectedSign(prediction);
                        setDetectedSignsHistory(prevSigns => [...prevSigns, prediction]);
                        setPreviousResult(prediction);
                        setTimeout(() => {
                          setPreviousResult('No hand detected');
                        }, 5000); // Wait for 5 seconds before allowing the next prediction
                      }
                    }
                  })
                  .catch(error => {
                    console.error('Error predicting sign:', error);
                    setResult(null);
                  });
              }
            }
            return 5; // Reset timer to 5 seconds
          }
          return prev - 1;
        });
      }, 1000); // Update timer every second
      
      setIntervalId(id);
    } else {
      // Clear interval if turning off
      if (intervalId) {
        clearInterval(intervalId);
        setIntervalId(null);
      }
    }
  };

  const toggleLiveLetterDetection = () => {
    setIsLiveLetter(!isLiveLetter);
    setIsLive(false);
    
    // If turning on live letter detection
    if (!isLiveLetter) {
      const id = setInterval(() => {
        if (webcamRef.current) {
          const imageSrc = webcamRef.current.getScreenshot();
          if (imageSrc) {
            // Don't set captured image in live mode to keep the webcam feed visible
            predictSign(imageSrc)
              .then(prediction => {
                setResult(prediction);
                if (prediction && prediction !== 'No hand detected') {
                  if (previousResult === 'No hand detected') {
                    setDetectedSign(prediction);
                    setDetectedSignsHistory(prevSigns => [...prevSigns, prediction]);
                    setPreviousResult(prediction);
                    setTimeout(() => {
                      setPreviousResult('No hand detected');
                    }, 5000); // Wait for 5 seconds before allowing the next prediction
                  }
                }
              })
              .catch(error => {
                console.error('Error predicting sign:', error);
                setResult(null);
              });
          }
        }
      }, 1000); // Predict every second
      
      setIntervalId(id);
    } else {
      // Clear interval if turning off
      if (intervalId) {
        clearInterval(intervalId);
        setIntervalId(null);
      }
    }
  };

  const stopLiveDetection = () => {
    setIsLive(false);
    setIsLiveLetter(false);
    if (intervalId) {
      clearInterval(intervalId);
      setIntervalId(null);
    }
  };

  const clearTextBoxes = () => {
    setDetectedSign(null);
    setProcessedSigns([]);
    setDetectedSignsHistory([]);
    setResult(null);
  };
  
  // Clean up interval on unmount
  useEffect(() => {
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [intervalId]);

  // Effect to process detected signs history
  useEffect(() => {
    const processSigns = (signs: string[]) => {
      if (signs.length === 0) return [];
      const processed: string[] = [];
      let count = 1;
      for (let i = 1; i <= signs.length; i++) {
        if (signs[i] === signs[i - 1]) {
          count++;
        } else {
          if (count >= 4) {
            processed.push(signs[i - 1], signs[i - 1]);
          } else {
            processed.push(signs[i - 1]);
          }
          count = 1;
        }
      }
      return processed;
    };

    setProcessedSigns(processSigns(detectedSignsHistory));
  }, [detectedSignsHistory]);

  const videoConstraints = {
    width: 720,
    height: 480,
    facingMode: "user", // Use "environment" for the rear camera
  };

  const speakText = () => {
    const text = processedSigns.join('');
    const utterance = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="card overflow-hidden">
      <div className="flex flex-col items-center">
        <div className="relative w-full max-w-md aspect-video rounded-lg overflow-hidden border-2 border-dark-lightest">
          {isEnabled ? (
            capturedImage && !isLive && !isLiveLetter ? (
              <div className="relative h-full">
                <img 
                  src={capturedImage} 
                  alt="Captured" 
                  className="w-full h-full object-cover"
                />
                {result && (
                  <motion.div 
                    className="absolute bottom-0 left-0 right-0 bg-accent/20 backdrop-blur-sm p-4 text-center"
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <h3 className="text-xl font-semibold text-white">Detected Sign:</h3>
                    <p className="text-2xl font-bold text-accent neon-text">{result}</p>
                  </motion.div>
                )}
                {loading && !result && (
                  <motion.div 
                    className="absolute bottom-0 left-0 right-0 bg-accent/20 backdrop-blur-sm p-4 text-center"
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <p className="text-xl font-semibold text-white">Detecting sign...</p>
                  </motion.div>
                )}
              </div>
            ) : (
              <div className="relative h-full">
                <Webcam
                  audio={false}
                  ref={webcamRef}
                  screenshotFormat="image/jpeg"
                  videoConstraints={videoConstraints}
                  className="w-full h-full object-cover"
                  style={{
                    transform: "scaleX(-1)", // Flip the camera horizontally
                  }}
                />
                
                {/* Timer overlay */}
                {showTimer && (
                  <motion.div 
                    className="absolute inset-0 bg-black/50 flex items-center justify-center"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    <motion.div
                      className="text-6xl font-bold text-white"
                      key={timer}
                      initial={{ scale: 1.5, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.5 }}
                    >
                      {timer}
                    </motion.div>
                  </motion.div>
                )}
                
                {result && (isLive || isLiveLetter) && (
                  <motion.div 
                    className="absolute bottom-0 left-0 right-0 bg-accent/20 backdrop-blur-sm p-4 text-center"
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <h3 className="text-xl font-semibold text-white">Detected Sign:</h3>
                    <p className="text-2xl font-bold text-accent neon-text">{result}</p>
                  </motion.div>
                )}
                
                {/* Live detection timer */}
                {isLive && (
                  <div className="absolute top-2 right-2 bg-black/50 text-white p-2 rounded-lg">
                    {liveTimer}
                  </div>
                )}
              </div>
            )
          ) : (
            <div className="flex items-center justify-center h-full bg-primary-dark">
              <Camera className="w-16 h-16 text-dark-lightest opacity-50" />
            </div>
          )}
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 mt-4">
          {!isEnabled ? (
            <button
              onClick={toggleWebcam}
              className="btn-primary flex items-center justify-center gap-2"
            >
              <Camera size={20} />
              Turn On Camera
            </button>
          ) : capturedImage && !isLive && !isLiveLetter ? (
            <>
              <button
                onClick={toggleWebcam}
                className="btn-warning flex items-center justify-center gap-2"
              >
                <CameraOff size={20} />
                Turn Off Camera
              </button>
              <button
                onClick={reset}
                className="btn-success flex items-center justify-center gap-2"
              >
                <RefreshCw size={20} />
                Try Another Sign
              </button>
            </>
          ) : (
            <>
              <button
                onClick={toggleWebcam}
                className="btn-warning flex items-center justify-center gap-2"
              >
                <CameraOff size={20} />
                Turn Off Camera
              </button>
              
              {!isLive && !isLiveLetter && !showTimer && (
                <button
                  onClick={startTimer}
                  className="btn-accent flex items-center justify-center gap-2"
                >
                  <Clock size={20} />
                  Capture with Timer
                </button>
              )}
              
              {!isLive && !isLiveLetter && !showTimer && (
                <button
                  onClick={capture}
                  className="btn-primary flex items-center justify-center gap-2"
                >
                  <Camera size={20} />
                  Capture Now
                </button>
              )}
              
              {showTimer && (
                <button
                  onClick={stopTimer}
                  className="btn-warning flex items-center justify-center gap-2"
                >
                  <X size={20} />
                  Cancel Timer
                </button>
              )}
              
              <button
                onClick={toggleLiveDetection}
                className={`btn-${isLive ? 'danger' : 'success'} flex items-center justify-center gap-2`}
              >
                <Play size={20} className={isLive ? "animate-pulse" : ""} />
                {isLive ? 'Stop Continuous Prediction of Word' : 'Start Continuous Prediction of Word'}
              </button>

              <button
                onClick={toggleLiveLetterDetection}
                className={`btn-${isLiveLetter ? 'danger' : 'success'} flex items-center justify-center gap-2`}
              >
                <Play size={20} className={isLiveLetter ? "animate-pulse" : ""} />
                {isLiveLetter ? 'Stop Continuous Prediction of Letter' : 'Start Continuous Prediction of Letter'}
              </button>
            </>
          )}
        </div>

        {capturedImage && !isLive && !isLiveLetter && (
          <>
            <div className="mt-4 w-full max-w-md">
              <input
                type="text"
                className="w-full p-2 border border-dark-lightest rounded-lg bg-dark-lighter text-white"
                value={detectedSign || ''}
                readOnly
              />
            </div>
            <div className="mt-4 flex gap-4">
              <button
                onClick={speakText}
                className="btn-primary flex items-center justify-center gap-2"
              >
                <Volume2 size={20} />
                Speak
              </button>
            </div>
          </>
        )}

        {isLive && (
          <>
            <div className="mt-4 w-full max-w-md">
              <input
                type="text"
                className="w-full p-2 border border-dark-lightest rounded-lg bg-dark-lighter text-white"
                value={processedSigns.join('')}
                readOnly
              />
            </div>

            <div className="mt-4 flex gap-4">
              <button
                onClick={speakText}
                className="btn-primary flex items-center justify-center gap-2"
              >
                <Volume2 size={20} />
                Speak
              </button>
              <button
                onClick={clearTextBoxes}
                className="btn-secondary flex items-center justify-center gap-2"
              >
                Clear
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default WebcamCapture;